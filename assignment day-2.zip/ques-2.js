var array = [1, 2, 3, 4, 5, 6],
    s = 0,
    i;
for (i = 0; i < array.length; i += 1) 
   {
    s += array[i];
    }
console.log('Sum : '+s);