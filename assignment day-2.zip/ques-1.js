const clothes = ['jacket', 't-shirt'];
clothes.length = 0;
console.log(clothes[0]);

// Here value of clothes[0] is undefined because we have set length of the array clothes to 0.
// Hence the whole array is empty i.e., it contains no elements.